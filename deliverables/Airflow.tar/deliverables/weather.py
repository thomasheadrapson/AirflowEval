try:
    from airflow import DAG
    from airflow.utils.dates import days_ago
    from airflow.operators.python import PythonOperator
    from airflow.utils.task_group import TaskGroup
    from airflow.models import Variable
    from datetime import datetime
    import requests
    import json
    import pandas as pd
    import os
    from sklearn.model_selection import cross_val_score
    from sklearn.linear_model import LinearRegression
    from sklearn.tree import DecisionTreeRegressor
    from sklearn.ensemble import RandomForestRegressor
    import joblib
except Exception as e:
    print(f'Exception : {e}')

def create_folder(folder_name):
    try:
        os.makedirs(folder_name, exist_ok=True) 
        print(f"Folder '{folder_name}' created successfully.")
    except Exception as e:
        print(f"Error creating folder: {e}")


def extract_data():
    cities = Variable.get("cities", deserialize_json = True)
    
    raw_files_folder = Variable.get("raw_files_folder", deserialize_json = True)
    
    cities_data = []
    for city in cities:
        data_time = datetime.now().strftime('%Y-%m-%d %H:%M')
        url = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid=92d83785320da490c55fd4fcdc96f921'
        r = requests.get(url)
        city_data = r.json()
        cities_data.append(city_data)
    # save city data
    data_file_name = f'{data_time}.json'
    with open(os.path.join(raw_files_folder,data_file_name), 'w') as f:
        json.dump(cities_data, f)
    
        
        
        
def transform_data(n_files=None, filename = 'data.csv'):
    raw_files_folder = Variable.get("raw_files_folder", deserialize_json = True)
    
    clean_data_folder = Variable.get("clean_data_folder", deserialize_json = True)

    files = sorted(os.listdir(raw_files_folder), reverse=True)
    if n_files:
            files = files[:n_files]

    dfs = []

    for f in files:
        with open(os.path.join(raw_files_folder, f), 'r') as file:
                data_temp = json.load(file)
        for data_city in data_temp:
            dfs.append(
            {
            'temperature': data_city['main']['temp'],
            'city': data_city['name'],
            'pression': data_city['main']['pressure'],
            'date': f.split('.')[0]
            }
        )

    df = pd.DataFrame(dfs)

    df.to_csv(os.path.join(clean_data_folder, filename), index = False)
    
    if not n_files:
        df = df.sort_values(['city', 'date'], ascending = True)

        dfs = []

        for c in df['city'].unique():
            df_temp = df[df['city'] == c]

            # creating target
            df_temp.loc[:, 'target'] = df_temp['temperature'].shift(1)

            # creating features
            for i in range(1, 10):
                df_temp.loc[:, 'temp_m-{}'.format(i)
                            ] = df_temp['temperature'].shift(-i)

            # deleting null values
            df_temp = df_temp.dropna()

            dfs.append(df_temp)

        # concatenating datasets
        df_final = pd.concat(
            dfs,
            axis=0,
            ignore_index=False
            )
        
        # deleting date variable
        df_final = df_final.drop(['date'], axis=1)

        # creating dummies for city variable
        df_final = pd.get_dummies(df_final)


        X = df_final.drop(['target'], axis=1)
        X.to_csv(f'{clean_data_folder}/X.csv')
        
        y = df_final['target']
        y.to_pickle(f'{clean_data_folder}/y.pkl')
        



def compute_model_score(task_instance, model):
    clean_data_folder = Variable.get("clean_data_folder", deserialize_json = True)
    X = pd.read_csv(f'{clean_data_folder}/X.csv')
    y = pd.read_pickle(f'{clean_data_folder}/y.pkl')
    # computing cross val
    cross_validation = cross_val_score(
        model,
        X,
        y,
        cv=3,
        scoring='neg_mean_squared_error')

    model_score = cross_validation.mean()
    model_name = str(model)[:-2]
    task_instance.xcom_push(
        key = model_name,
        value = model_score)



def train_and_save_model(model, path_to_model = '/app/clean_data/model.pckl'):
    # '/app/model.pckl' was giving a write error, so used '/app/clean_data/model.pckl' instead.
    
    clean_data_folder = Variable.get("clean_data_folder", deserialize_json = True)
    X = pd.read_csv(f'{clean_data_folder}/X.csv')
    y = pd.read_pickle(f'{clean_data_folder}/y.pkl')
    # training the model
    model.fit(X, y)
    # saving model
    model_name = str(model)[:-2]
    print(model_name, 'saved at ', path_to_model)
    joblib.dump(model, path_to_model)
    

def evaluate_models_and_select(task_instance):
    models = Variable.get('models', deserialize_json = True)
    best_score = -10000000000
    for model_name in models:
        score = task_instance.xcom_pull(
            key = f'{model_name}',
            task_ids = [f'SCORE.{model_name}',]
            )[0]
        if score > best_score:
            best_score = score
            best_model_name = model_name
    best_model_class = globals()[best_model_name]
    best_model = best_model_class()
    train_and_save_model(best_model)

 
    
with DAG(
    dag_id='weather_dag',
    description='Evaluation dag for DataScientest Airflow module',
    tags=['evaluation', 'datascientest'],
    schedule_interval= '* * * * *',
    default_args={
        'owner': 'airflow',
        'start_date': days_ago(0, minute = 1),
        },
    catchup = False
    ) as weather_dag:

### EXTRACT STAGE ###

    extract = PythonOperator(
        task_id='EXTRACT',
        python_callable=extract_data,
    )    

### TRANSFORM STAGE ###
    with TaskGroup("TRANSFORM") as transform:
        transform_2 =  PythonOperator(
            task_id='TRANSFORM_2',
            python_callable=transform_data,
            op_kwargs = {
                'n_files': 20
                }
            )
        transform_3 = PythonOperator(
            task_id = "TRANSFORM_3",
            python_callable=transform_data,
            op_kwargs = {
                'filename': 'fulldata.csv'
                }
            )
        
### SCORE STAGE ###
          
    models = Variable.get('models', deserialize_json = True)
    with TaskGroup("SCORE") as score:
        tasks4 = []
        for model_name in models:
            model_class = globals()[model_name]
            model = model_class()
            task = PythonOperator(
                task_id = model_name,
                python_callable=compute_model_score,
                op_kwargs = {'model': model},
                provide_context=True
            )
            tasks4.append(task)

        
### SELECT STAGE ###

    select = PythonOperator(
        task_id='SELECT',
        python_callable=evaluate_models_and_select,
        provide_context=True
        )


extract >> transform
transform >> score
score >> select
